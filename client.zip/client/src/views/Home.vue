<template>
<div>
  <header>
    <img class="img-fluid d-block mx-auto mt-3 mb-5" src="../assets/banner.jpg">
  </header>

  <div class="container text-center" style="background-color: #C0C0C0">
    <h1>LATEST NEWS!</h1>
  </div>

  <!-- Content section -->
  <section class="py-3">
    <div class="container">
      <h3>Travis Scott Reveals Early Sample Of His Nike SB Dunk Low Collaboration</h3>
      <p class="lead"> COLLABORATION DUNK SAMPLE NIKE SB DUNK LOW TRAVIS SCOTT</p>
      <p>One way the sneaker community is passing the time during this social distancing quarantine is by revealing measured peeks into sneaker collections. Travis Scott isn’t an exception to this trend, because the Houston-based collaborator – possibly due to boredom – just revealed an early sample of his Nike SB Dunk Low collaboration, the shoe that dominated the headlines throughout the month of February. It appears that the sample is akin the base of the existing version as it doesn’t boast the removable bandana-patterned layer nor the plain mid-foot. The brown outsole is possibly based on La Flame’s personal favorite – the “Trail End” SB Dunk that actually inspired his Air Jordan 1 High design. Do you prefer these over the final version, or are you glad he and Nike expanding upon this design?</p>
    </div>
  </section>

  <!-- Content section -->
  <section class="py-4">
    <div class="container">
      <h3>The Nike Air Max 90 “Duck Camo” Releases Tomorrow</h3>
      <p class="lead"> AIR MAX 90 NIKE AIR MAX RELEASE DATES UPCOMING SNEAKERS NIKE AIR MAX 90</p>
      <p>After first being spotted late last month, the Air Max 90 Duck Camo is finally hitting retailers tomorrow, March 26th. While undoubtedly rooted in Nike’s 2013 collaboration with atmos, the Air Max Day 2020-headliner is more than a revisited design. Tomorrow’s drop speaks to the timelessness of the Air Max 90 silhouette as a whole. Previous camouflage applications on other NIKE, Inc. footwear have appeased enthusiasts, but arguably none have rivaled the ’90’s first impression. As notable as the green-based patterns are, adjacent “Infrared” arrangements demand the spotlight. Mixing the covert with the overt shouldn’t work, but it does because the Air Max 90 was designed with both understated and exaggerated DNA that has lasted the test of time 30 years later. Enjoy another look at the Air Max 90 “Duck Camo” here below and find an extensive store list ahead. Elsewhere in the world of anniversary-celebrating Air Max sneakers, the Air Max 95 is soon arriving in an impressive “Gunsmoke/Pink Foam” colorway.</p>
    </div>
  </section>


  <!-- Content section -->
  <section class="py-4">
    <div class="container">
      <h3>Air Jordan Retro Preview For 2020</h3>
      <p class="lead"> AIR JORDAN RELEASE DATES UPCOMING SNEAKERS AIR JORDAN 1 AIR JORDAN 1 RETRO HIGH OG AIR JORDAN 12 AIR JORDAN 13 AIR JORDAN 14 AIR JORDAN 3</p>
      <p>Although we’ve still got the holiday season’s wide offering of Jordan releases to look forward to, early info on the Jumpman’s 2020 slate has begun to surface, and there’s a solid selection of new takes on beloved retro models that are sure to appease even the most finicky JB fan. The Air Jordan 3 will receive a “UNC” makeup in March that’s similar to the infamous football PEs that got the Tar Heel football squad in trouble last year, sans the embroidered NC logo on the tongue. After that, we’re looking ahead to July with four fresh makeups. First up is an Air Jordan 1 Retro High OG “Neutral Grey” that’ll likely feature a subtle palette, something that always works well on the high-cut classic. Then, there’s the Air Jordan 13 “Lucky Green,” a white/black/green colorway that may very well be a callout to Ray Allen‘s famous, ultra-rare AJ13 PEs. The Air Jordan 12 will see a striking “University Gold” style, and last but not least the Air Jordan 14 “Hyper Royal” will keep things all the way sporty with a Rip Hamilton-esque color scheme. Check out all five pairs below, and please note that they’re all mockups — save for the UNC, of which the PE edition is pictured — so the final release versions may be vastly different. When you’re done, be sure to head over to our Jordan Release Dates page to see what else Jordan Brand has on the way over the coming months.</p>
    </div>
  </section>
</div>

</template>

<script>
export default {
  name: 'home',

}
</script>