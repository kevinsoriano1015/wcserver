<template>
<div class="container">
    <header>
        <img class="img-fluid d-block mx-auto mt-3 mb-5" src="../assets/ign2.png">
    </header>
    <!--Start code-->
    <div class="row">
        <div class="col-12 pb-5">
            <section class="row">
                <div class="col-12 col-md-6 pb-0 pb-md-3 pt-2 pr-md-1">
                    <div id="featured" class="carousel slide carousel" data-ride="carousel">
                        <div class="carousel-inner">
                            <div class="carousel-item active">
                                <div class="card border-0 rounded-0 text-light overflow zoom">
                                    <div class="position-relative">
                                        <div class="ratio_left-cover-1 image-wrapper">
                                            <a>
                                                <img class="img-fluid w-100"
                                                     src="../assets/3.jpg"
                                                     alt="Bootstrap news template" style="height: 470px">
                                            </a>
                                        </div>
                                        <div class="position-absolute p-2 p-lg-3 b-0 w-100 bg-shadow">
                                            <a>
                                                <h2 class="h3 post-title text-white my-1">Travis Scott Reveals Early Sample Of His Nike SB Dunk Low Collaboration</h2>
                                            </a>
                                            <div class="news-meta">
                                                <p>One way the sneaker community is passing the time during this social distancing quarantine is by revealing measured peeks into sneaker collections. </p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-12 col-md-6 pt-2 pl-md-1 mb-3 mb-lg-4">
                    <div class="row">
                        <div class="col-6 pb-1 pt-0 pr-1">
                            <div class="card border-0 rounded-0 text-white overflow zoom">
                                <div class="position-relative">
                                    <div class="ratio_right-cover-2 image-wrapper">
                                        <a>
                                            <img class="img-fluid"
                                                src="../assets/1.jpg"
                                                style="height: 230px">
                                        </a>
                                    </div>
                                    <div class="position-absolute p-2 p-lg-3 b-0 w-100 bg-shadow">
                                        <a>
                                            <h2 class="h6 text-white my-1">The Nike Air Max 90 “Duck Camo” Releases Tomorrow</h2>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-6 pb-1 pl-1 pt-0">
                            <div class="card border-0 rounded-0 text-white overflow zoom">
                                <div class="position-relative">
                                    <div class="ratio_right-cover-2 image-wrapper">
                                        <a>
                                            <img class="img-fluid"
                                                 src="../assets/2.jpg"
                                                style="height: 230px;">
                                        </a>
                                    </div>
                                    <div class="position-absolute p-2 p-lg-3 b-0 w-100 bg-shadow">
                                        <a>
                                            <h2 class="h6 text-white my-1">Air Jordan Retro Preview For 2020</h2>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-6 pb-1 pr-1 pt-1">
                            <div class="card border-0 rounded-0 text-white overflow zoom">
                                <div class="position-relative">
                                    <div class="ratio_right-cover-2 image-wrapper">
                                        <a>
                                            <img class="img-fluid"
                                                src="../assets/6.jpg"
                                                style="height: 230px;">
                                        </a>
                                    </div>
                                    <div class="position-absolute p-2 p-lg-3 b-0 w-100 bg-shadow">
                                        <a>
                                            <h2 class="h6 text-white my-1">Adidas Yeezy Boost 350 v2 Appears In “Oreo” Style Colorway</h2>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-6 pb-1 pl-1 pt-1">
                            <div class="card border-0 rounded-0 text-white overflow zoom">
                                <div class="position-relative">
                                    <div class="ratio_right-cover-2 image-wrapper">
                                        <a>
                                            <img class="img-fluid"
                                                 src="../assets/5.jpg"
                                                style="height: 230px;">
                                        </a>
                                    </div>
                                    <div class="position-absolute p-2 p-lg-3 b-0 w-100 bg-shadow">
                                        <a>
                                            <h2 class="h6 text-white my-1">Where To Buy The Fear Of God ESSENTIALS x Converse Chuck 70 “Black”</h2>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
    
    <div class="row mb-4">
        <div class="col-12 text-center">
            <p>Design by Ari Budin <a target="_blank" href="https://bootstrap.news/bootstrap-4-template-news-portal-magazine/">Bootstrap.News</a> | images by pixabay and pexels</p>
        </div>
    </div>
</div>
</template>

<style>


.b-0 {
    bottom: 0;
}
.bg-shadow {
    background: rgba(76, 76, 76, 0);
    background: -webkit-gradient(left top, left bottom, color-stop(0%, rgba(179, 171, 171, 0)), color-stop(49%, rgba(48, 48, 48, 0.37)), color-stop(100%, rgba(19, 19, 19, 0.8)));
    background: linear-gradient(to bottom, rgba(179, 171, 171, 0) 0%, rgba(48, 48, 48, 0.71) 49%, rgba(19, 19, 19, 0.8) 100%);
    filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#4c4c4c', endColorstr='#131313', GradientType=0 );
}
.top-indicator {
    right: 0;
    top: 1rem;
    bottom: inherit;
    left: inherit;
    margin-right: 1rem;
}
.overflow {
    position: relative;
    overflow: hidden;
}
.zoom img {
    transition: all 0.2s linear;
}
.zoom:hover img {
    -webkit-transform: scale(1.1);
    transform: scale(1.1);
}
</style>