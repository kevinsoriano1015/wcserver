<template>
    <footer class="site-footer" style="background-color: #000000">
      <div class="container">
        <div class="row">
          <div class="col-sm-12 col-md-6">
            <h6>Why Sneakerhead</h6>
            <p class="text-justify">With 100% authentic products (including Nike, Air Jordan, Puma, Timberland, Adidas) and a sophisticated customer service system, Sneakerhead.com has one of the best reputations among online sneaker retailers. We're proud to be a Yahoo! 5-star rated merchant and a member of the Better Business Bureau. We always strive to make your online shopping experience the best it can be. Check out some of our customer reviews, and thank you for choosing Sneakerhead.com.
              
            </p>
          </div>

          <div class="col-xs-6 col-md-3">
            <h6>ABOUT Sneakerhead</h6>
            <ul class="footer-links">
              <li><a href="#">Contact</a></li>
              <li><a href="#">Advertise</a></li>
              <li><a href="#">Press</a></li>
              <li><a href="#">User Agreement</a></li>
              <li><a href="#">Privacy Policy</a></li>
              <li><a href="#">Cookie Policy</a></li>
            </ul>
          </div>

          <div class="col-xs-6 col-md-3">
            <h6>Sneakers</h6>
            <ul class="footer-links">
              <li><a href="http://scanfcode.com/about/">Adidas</a></li>
              <li><a href="http://scanfcode.com/contact/">Yeezy</a></li>
              <li><a href="http://scanfcode.com/contribute-at-scanfcode/">Jordan</a></li>
              <li><a href="http://scanfcode.com/privacy-policy/">Nike</a></li>
              <li><a href="http://scanfcode.com/sitemap/">Converse</a></li>
            </ul>
          </div>
        </div>
        <hr>
      </div>
      <div class="container">
        <div class="row">
          <div class="col-md-8 col-sm-6 col-xs-12">
            <p class="copyright-text">Copyright © 2001 - 2020 Sneakerhead.com. All Rights Reserved.</p>
          </div>
        </div>
      </div>
</footer>
</template>

<style>
.site-footer
{
  background-color:#26272b;
  padding:45px 0 20px;
  font-size:15px;
  line-height:24px;
  color:whitesmoke;
}
.site-footer hr
{
  border-top-color: white;
  opacity:0.5
}
.site-footer hr.small
{
  margin:20px 0
}
.site-footer h6
{
  color:whitesmoke;
  font-size:16px;
  text-transform:uppercase;
  margin-top:5px;
  letter-spacing:2px
}
.site-footer a
{
  color:whitesmoke;
}
.site-footer a:hover
{
  color:#3366cc;
  text-decoration:none;
}
.footer-links
{
  padding-left:0;
  list-style:none
}
.footer-links li
{
  display:block
}
.footer-links a
{
  color:whitesmoke
}
.footer-links a:active,.footer-links a:focus,.footer-links a:hover
{
  color:#3366cc;
  text-decoration:none;
}
.footer-links.inline li
{
  display:inline-block
}
.site-footer .social-icons
{
  text-align:right
}
.site-footer .social-icons a
{
  width:40px;
  height:40px;
  line-height:40px;
  margin-left:6px;
  margin-right:0;
  border-radius:100%;
  background-color:#33353d
}
.copyright-text
{
  margin:0
}
@media (max-width:991px)
{
  .site-footer [class^=col-]
  {
    margin-bottom:30px
  }
}
@media (max-width:767px)
{
  .site-footer
  {
    padding-bottom:0
  }
  .site-footer .copyright-text,.site-footer .social-icons
  {
    text-align:center
  }
}
</style>